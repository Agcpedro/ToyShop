﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using LojaBrinquedos.Data;
using ToyShop.Models;

namespace LojaBrinquedos.Controllers
{
    public class ToyController : Controller
    {
        private readonly LojaBrinquedosContext _context;

        public ToyController(LojaBrinquedosContext context)
        {
            _context = context;
        }

        // GET: Toy
        public async Task<IActionResult> Index()
        {
            var lojaBrinquedosContext = _context.ToyModel.Include(t => t.ClientModel);
            return View(await lojaBrinquedosContext.ToListAsync());
        }

        // GET: Toy/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var toyModel = await _context.ToyModel
                .Include(t => t.ClientModel)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (toyModel == null)
            {
                return NotFound();
            }

            return View(toyModel);
        }

        // GET: Toy/Create
        public IActionResult Create()
        {
            ViewData["ClientModelId"] = new SelectList(_context.ClientModel, "Id", "Name");
            return View();
        }

        // POST: Toy/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Name,Price,Category,AgeRecommendation,ClientModelId")] ToyModel toyModel)
        {
            _context.Add(toyModel);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        // GET: Toy/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var toyModel = await _context.ToyModel.FindAsync(id);
            if (toyModel == null)
            {
                return NotFound();
            }
            ViewData["ClientModelId"] = new SelectList(_context.ClientModel, "Id", "Name", toyModel.ClientModelId);
            return View(toyModel);
        }

        // POST: Toy/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Name,Price,Category,AgeRecommendation,ClientModelId")] ToyModel toyModel)
        {
            if (id != toyModel.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(toyModel);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ToyModelExists(toyModel.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["ClientModelId"] = new SelectList(_context.ClientModel, "Id", "Address", toyModel.ClientModelId);
            return View(toyModel);
        }

        // GET: Toy/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var toyModel = await _context.ToyModel
                .Include(t => t.ClientModel)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (toyModel == null)
            {
                return NotFound();
            }

            return View(toyModel);
        }

        // POST: Toy/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var toyModel = await _context.ToyModel.FindAsync(id);
            if (toyModel != null)
            {
                _context.ToyModel.Remove(toyModel);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ToyModelExists(int id)
        {
            return _context.ToyModel.Any(e => e.Id == id);
        }
    }
}
