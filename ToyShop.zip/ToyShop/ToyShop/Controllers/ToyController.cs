﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using ToyShop.Data;
using ToyShop.Models;

namespace ToyShop.Controllers
{
    public class ToyController : Controller
    {
        private readonly ToyShopContext _context;

        public ToyController(ToyShopContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index()
        {
            return View(await _context.ToyModel.ToListAsync());
        }

        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var toyModel = await _context.ToyModel
                .FirstOrDefaultAsync(m => m.Id == id);
            if (toyModel == null)
            {
                return NotFound();
            }

            return View(toyModel);
        }

        public IActionResult Create()
        {
            return View();
        }


        [HttpPost]
        public async Task<IActionResult> Create([Bind("Id,Name,Price,Category,AgeRecommendation")] ToyModel toyModel)
        {
            if (ModelState.IsValid)
            {
                _context.Add(toyModel);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(toyModel);
        }

        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var toyModel = await _context.ToyModel.FindAsync(id);
            if (toyModel == null)
            {
                return NotFound();
            }
            return View(toyModel);
        }

        [HttpPost]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Name,Price,Category,AgeRecommendation")] ToyModel toyModel)
        {
            if (id != toyModel.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(toyModel);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ToyModelExists(toyModel.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(toyModel);
        }

        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var toyModel = await _context.ToyModel
                .FirstOrDefaultAsync(m => m.Id == id);
            if (toyModel == null)
            {
                return NotFound();
            }

            return View(toyModel);
        }

        [HttpPost, ActionName("Delete")]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var toyModel = await _context.ToyModel.FindAsync(id);
            if (toyModel != null)
            {
                _context.ToyModel.Remove(toyModel);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ToyModelExists(int id)
        {
            return _context.ToyModel.Any(e => e.Id == id);
        }
    }
}
