﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using ToyShop.Models;

namespace ToyShop.Data
{
    public class ToyShopContext : DbContext
    {
        public ToyShopContext(DbContextOptions<ToyShopContext> options)
            : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<ClientModel>()
                .HasMany(c => c.Toys)
                .WithOne(t => t.ClientModel)
                .HasForeignKey(t => t.ClientModelId)
                .OnDelete(DeleteBehavior.Cascade); // Define o comportamento de exclusão em cascata
        }

        public DbSet<ClientModel> ClientModel { get; set; } = default!;
        public DbSet<ToyModel> ToyModel { get; set; } = default!;
    }
}
