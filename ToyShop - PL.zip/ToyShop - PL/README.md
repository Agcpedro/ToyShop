Base Completa (LojaBrinquedos) a (ToyShop é a versão antiga) podia ter criado um branch mas fiquei com preguiça

Deve ter que rodar "Update-Database" no console de pacotes , pra criar a base de dado

Teoricamente a base que o Rosen pediu ta feita, com uma relação 1:N de clientes e produtos que compraram (Que um cliente pode comprar vários produtos)
A ideia é criar um cliente e depois criar uma "compra" e ai associar o nome dele

Ainda tem que limpar ele um pouco, o Private pode sair é o home pode ser deletado ou transformado numa pagina de entrada melhor
Tem como mexer no css , e se alguem quiser pode fazer que no cliente apareça as produtos que ele comprou (isso talvez de mais problema)
