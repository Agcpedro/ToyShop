﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using ToyShop.Models;
//ToyShop\LojaBrinquedos\LojaBrinquedos\Data\LojaBrinquedosContext.cs
namespace LojaBrinquedos.Data
{
    public class LojaBrinquedosContext : DbContext
    {
        public LojaBrinquedosContext (DbContextOptions<LojaBrinquedosContext> options)
            : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<ClientModel>()
                .HasMany(c => c.Toys)
                .WithOne(t => t.ClientModel)
                .HasForeignKey(t => t.ClientModelId)
                .OnDelete(DeleteBehavior.Cascade); // Define o comportamento de exclusão em cascata
        }

        public DbSet<ToyShop.Models.ClientModel> ClientModel { get; set; } = default!;
        public DbSet<ToyShop.Models.ToyModel> ToyModel { get; set; } = default!;
    }
}
