﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace ToyShop.Models
{
    public class ToyModel
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "O nome do brinquedo é obrigatório.")]
        [StringLength(100, ErrorMessage = "O nome do brinquedo não pode ter mais de 100 caracteres.")]
        [DisplayName("Nome do Brinquedo")]
        public string Name { get; set; } = string.Empty;

        [Required(ErrorMessage = "O preço é obrigatório.")]
        [Range(1, 1000, ErrorMessage = "O preço deve estar entre 1 e 1000.")]
        [DisplayName("Preço")]
        public int Price { get; set; }

        [Required(ErrorMessage = "A categoria é obrigatória.")]
        [StringLength(50, ErrorMessage = "A categoria não pode ter mais de 50 caracteres.")]
        [DisplayName("Categoria")]
        public string Category { get; set; } = string.Empty;

        [Required(ErrorMessage = "A idade recomendada é obrigatória.")]
        [Range(0, 18, ErrorMessage = "A idade recomendada deve estar entre 0 e 18 anos.")]
        [DisplayName("Idade Recomendada")]
        public int AgeRecommendation { get; set; }

        // Chave estrangeira
        [DisplayName("Nome do Comprador")]
        public int ClientModelId { get; set; }

        [DisplayName("Nome do Comprador")]
        public ClientModel ClientModel { get; set; } = new ClientModel();
    }
}
