﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
//\LojaBrinquedos\LojaBrinquedos\Models\ClientModel.cs
namespace ToyShop.Models
{
    public class ClientModel
    {
        public int Id { get; set; }

        [DisplayName("Nome")]
        [Required(ErrorMessage = "O nome é obrigatório.")] // "required" faz que não pode ta vazio
        [StringLength(100, ErrorMessage = "O nome não pode ter mais de 100 caracteres.")]
        public string Name { get; set; } = string.Empty;

        [DisplayName("Email")]
        [Required(ErrorMessage = "O e-mail é obrigatório.")]
        [EmailAddress(ErrorMessage = "Insira um e-mail válido.")] // esse daqui ja é uma função pre-buildada pra identificaar  e validar email
        public string Email { get; set; } = string.Empty;

        [DisplayName("Telefone")]
        [Required(ErrorMessage = "O número de telefone é obrigatório.")]
        [RegularExpression(@"\(\d{2}\) \d{5}-\d{4}", ErrorMessage = "O número de telefone deve seguir o formato (99) 99999-9999.")] //Aqui peguei um regex que força o usuario a colocar nesse formato
        public string PhoneNumber { get; set; } = string.Empty;

        [Required(ErrorMessage = "O endereço é obrigatório.")]
        [StringLength(200, ErrorMessage = "O endereço não pode ter mais de 200 caracteres.")]
        public string Address { get; set; } = string.Empty;

        public List<ToyModel> Toys { get; set; } = new List<ToyModel>();
    }
}