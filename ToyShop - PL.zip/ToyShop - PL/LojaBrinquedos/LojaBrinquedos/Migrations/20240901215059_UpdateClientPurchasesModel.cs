﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace LojaBrinquedos.Migrations
{
    /// <inheritdoc />
    public partial class UpdateClientPurchasesModel : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
