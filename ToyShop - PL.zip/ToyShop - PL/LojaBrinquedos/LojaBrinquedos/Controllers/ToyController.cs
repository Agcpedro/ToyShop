﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using LojaBrinquedos.Data;
using ToyShop.Models;

namespace LojaBrinquedos.Controllers
{
    public class ToyController : Controller
    {
        private readonly LojaBrinquedosContext _context;

        public ToyController(LojaBrinquedosContext context)
        {
            _context = context;
        }

        // GET: Toy
        public async Task<IActionResult> Index()
        {
            var lojaBrinquedosContext = _context.ToyModel.Include(t => t.ClientModel);
            return View(await lojaBrinquedosContext.ToListAsync());
        }

        // GET: Toy/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var toyModel = await _context.ToyModel
                .Include(t => t.ClientModel)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (toyModel == null)
            {
                return NotFound();
            }

            return View(toyModel);
        }

        // GET: Toy/Create
        public IActionResult Create()
        {
            var toys = new List<ToyModel>
            {
                new ToyModel { Id = 1, Name = "Carrinho", Price = 50, Category = "Veículos", AgeRecommendation = 5 },
                new ToyModel { Id = 2, Name = "Boneca", Price = 70, Category = "Bonecas", AgeRecommendation = 3 },
                new ToyModel { Id = 3, Name = "Jogo de Tabuleiro", Price = 120, Category = "Jogos", AgeRecommendation = 10 },
                new ToyModel { Id = 4, Name = "Blocos de Montar", Price = 80, Category = "Construção", AgeRecommendation = 7 },
                new ToyModel { Id = 5, Name = "Pelúcia", Price = 40, Category = "Brinquedos de Pelúcia", AgeRecommendation = 2 }
            };

            ViewData["ClientModelId"] = new SelectList(_context.ClientModel, "Id", "Name");
            ViewData["ToyModelId"] = new SelectList(toys, "Id", "Name");

            return View();
        }

        // POST: Toy/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(int Id, int ClientModelId)
        {
            if (ModelState.IsValid)
            {
                var toys = new List<ToyModel>
                {
                    new ToyModel { Id = 1, Name = "Carrinho", Price = 50, Category = "Veículos", AgeRecommendation = 5 },
                    new ToyModel { Id = 2, Name = "Boneca", Price = 70, Category = "Bonecas", AgeRecommendation = 3 },
                    new ToyModel { Id = 3, Name = "Jogo de Tabuleiro", Price = 120, Category = "Jogos", AgeRecommendation = 10 },
                    new ToyModel { Id = 4, Name = "Blocos de Montar", Price = 80, Category = "Construção", AgeRecommendation = 7 },
                    new ToyModel { Id = 5, Name = "Pelúcia", Price = 40, Category = "Brinquedos de Pelúcia", AgeRecommendation = 2 }
                };

                var selectedToy = toys.FirstOrDefault(t => t.Id == Id);

                if (selectedToy == null)
                {
                    ModelState.AddModelError("", "O brinquedo selecionado não foi encontrado.");
                    return View();
                }

                var client = await _context.ClientModel.FindAsync(ClientModelId);
                if (client == null)
                {
                    ModelState.AddModelError("", "O comprador selecionado não foi encontrado.");
                    return View();
                }

                var newToy = new ToyModel
                {
                    Name = selectedToy.Name,
                    Price = selectedToy.Price,
                    Category = selectedToy.Category,
                    AgeRecommendation = selectedToy.AgeRecommendation,
                    ClientModelId = client.Id,
                    ClientModel = client
                };

                _context.Add(newToy);
                await _context.SaveChangesAsync();

                return RedirectToAction(nameof(Index));
            }

            ViewData["ClientModelId"] = new SelectList(_context.ClientModel, "Id", "Name", ClientModelId);
            return View();
        }

        // GET: Toy/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var toyModel = await _context.ToyModel.FindAsync(id);
            if (toyModel == null)
            {
                return NotFound();
            }

            ViewData["ClientModelId"] = new SelectList(_context.ClientModel, "Id", "Name", toyModel.ClientModelId);
            return View(toyModel);
        }

        // POST: Toy/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Name,Price,Category,AgeRecommendation,ClientModelId")] ToyModel toyModel)
        {
            if (id != toyModel.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    var existingToy = await _context.ToyModel.Include(t => t.ClientModel).FirstOrDefaultAsync(t => t.Id == id);

                    if (existingToy == null)
                    {
                        return NotFound();
                    }

                    existingToy.ClientModelId = toyModel.ClientModelId;
                    var client = await _context.ClientModel.FindAsync(toyModel.ClientModelId);

                    if (client == null)
                    {
                        ModelState.AddModelError("", "O comprador selecionado não foi encontrado.");
                        return View(toyModel);
                    }

                    existingToy.ClientModel = client;

                    _context.Update(existingToy);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ToyModelExists(toyModel.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["ClientModelId"] = new SelectList(_context.ClientModel, "Id", "Name", toyModel.ClientModelId);
            return View(toyModel);
        }

        // GET: Toy/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var toyModel = await _context.ToyModel
                .Include(t => t.ClientModel)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (toyModel == null)
            {
                return NotFound();
            }

            return View(toyModel);
        }

        // POST: Toy/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var toyModel = await _context.ToyModel.FindAsync(id);
            if (toyModel != null)
            {
                _context.ToyModel.Remove(toyModel);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ToyModelExists(int id)
        {
            return _context.ToyModel.Any(e => e.Id == id);
        }
    }
}
