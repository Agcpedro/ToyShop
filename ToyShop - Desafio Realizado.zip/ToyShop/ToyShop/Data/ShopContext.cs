﻿using ToyShop.Models;
using Microsoft.EntityFrameworkCore;

namespace ToyShop.Data
{

        public class ShopContext : DbContext
        {
            public ShopContext(DbContextOptions<ShopContext> options) : base(options)
            {
            }

            public DbSet<Toy> Toys { get; set; }
            public DbSet<Order> Orders { get; set; }
            public DbSet<Client> Clients { get; set; }
        
    }
}
