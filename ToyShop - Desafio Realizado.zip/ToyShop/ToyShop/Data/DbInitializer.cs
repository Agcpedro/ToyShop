﻿using ToyShop.Models;
using System;
using System.Linq;

namespace ToyShop.Data
{
    public static class DbInitializer
    {
        public static void Initialize(ShopContext context)
        {
            context.Database.EnsureCreated();

            // Verifica se já há algum cliente no banco de dados
            if (context.Clients.Any())
            {
                return;   // O BD já foi populado
            }

            // Adiciona alguns clientes (equivalente a "students" no exemplo da Microsoft)
            var clients = new Client[]
            {
                new Client{LastName="Silva", Email="carson@example.com", Telefone="999999999"},
                new Client{LastName="Oliveira", Email="meredith@example.com", Telefone="999999999"},
                new Client{LastName="Santos", Email="arturo@example.com", Telefone="999999999"},
                new Client{LastName="Barros", Email="gytis@example.com", Telefone="999999999"},
                new Client{LastName="Lima", Email="yan@example.com", Telefone="999999999"},
                new Client{LastName="Costa", Email="peggy@example.com", Telefone="999999999"},
                new Client{LastName="Rocha", Email="laura@example.com", Telefone="999999999"},
                new Client{LastName="Ribeiro", Email="nino@example.com", Telefone="999999999"}
            };
            foreach (Client c in clients)
            {
                context.Clients.Add(c);
            }
            context.SaveChanges();

            // Adiciona alguns brinquedos (equivalente a "courses" no exemplo da Microsoft)
            var toys = new Toy[]
            {
                new Toy{Nome="Carrinho", Preço=50, Description="Carrinho de controle remoto"},
                new Toy{Nome="Boneca", Preço=80, Description="Boneca com acessórios"},
                new Toy{Nome="Quebra-cabeça", Preço=30, Description="Quebra-cabeça de 500 peças"},
                new Toy{Nome="Jogo de tabuleiro", Preço=100, Description="Jogo de tabuleiro estratégico"},
                new Toy{Nome="Lego", Preço=150, Description="Lego de construção"},
                new Toy{Nome="Bola de futebol", Preço=40, Description="Bola oficial de futebol"},
                new Toy{Nome="Drone", Preço=300, Description="Drone com câmera"},
            };
            foreach (Toy t in toys)
            {
                context.Toys.Add(t);
            }
            context.SaveChanges();

            // Adiciona alguns pedidos (equivalente a "enrollments" no exemplo da Microsoft)
            var orders = new Order[]
            {
                new Order{ClientID=1, ToyID=1},
                new Order{ClientID=1, ToyID=2},
                new Order{ClientID=2, ToyID=3},
                new Order{ClientID=2, ToyID=4},
                new Order{ClientID=3, ToyID=5},
                new Order{ClientID=4, ToyID=6},
                new Order{ClientID=5, ToyID=1},
                new Order{ClientID=6, ToyID=7},
                new Order{ClientID=7, ToyID=2},
                new Order{ClientID=8, ToyID=3}
            };
            foreach (Order o in orders)
            {
                context.Orders.Add(o);
            }
            context.SaveChanges();
        }
    }
}
