﻿using System.ComponentModel.DataAnnotations;

namespace ToyShop.Models
{
    public class Client
    {

        public int ID { get; set; }

        [Display(Name = "Nome")]
        public string? LastName { get; set; }

        [Display(Name = "Email")]
        [EmailAddress(ErrorMessage = "O e-mail fornecido não é válido.")]
        public string? Email { get; set; }

        [Display(Name = "Telefone")]
        [Phone(ErrorMessage = "O número de telefone fornecido não é válido.")]
        public string? Telefone { get; set; }
        public ICollection<Order>? Orders { get; set; }
    }
}
