﻿using System.ComponentModel.DataAnnotations;

namespace ToyShop.Models
{
    public class Order
    {

            public int OrderID { get; set; }
        [Display(Name = "Nome do Brinquedo")]
        public int ToyID { get; set; }
        [Display(Name = "Nome do Cliente")]
        public int ClientID { get; set; }

            public Toy? Toy { get; set; }
            public Client? Client { get; set; }

    }
}
