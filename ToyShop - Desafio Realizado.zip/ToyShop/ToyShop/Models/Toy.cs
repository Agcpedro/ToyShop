﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ToyShop.Models
{
    public class Toy
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int ToyID { get; set; }

        [Display(Name = "Nome")]
        [Required(ErrorMessage = "O campo Nome é obrigatório.")]
        public string? Nome { get; set; }

        [Display(Name = "Preço")]
        [Range(0, int.MaxValue, ErrorMessage = "O preço deve ser um valor positivo.")]
        public int? Preço { get; set; }

        [Display(Name = "Descrição")]
        public string? Description { get; set; }

        public ICollection<Order>? Orders { get; set; }
    }
}
